from django.apps import AppConfig


class RegistrationAppConfig(AppConfig):
    name = 'Registration_App'
