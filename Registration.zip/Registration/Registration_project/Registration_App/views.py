from django.shortcuts import render, HttpResponseRedirect
from django.contrib.auth.forms import UserCreationForm,UserChangeForm
from .forms import SignupForm, EditUserProfileForm, EditAdminProfileForm
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm, PasswordChangeForm, SetPasswordForm
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.models import User

#api
from .serializers import UserSerializer, RegisterSerializer
from rest_framework import generics
from rest_framework.response import Response
from rest_framework.reverse import reverse
  



# Create your views here.
#signup
def signup(request):
    if request.method == 'POST':
        fm = SignupForm(request.POST)
        if fm.is_valid():
            messages.success(request, 'Account Created Successfuly!')
            fm.save()
    else:
       fm = SignupForm()
    return render(request, 'user/signup.html', {'form': fm})

#login
def user_login(request):
    if not  request.user.is_authenticated:
        if request.method == 'POST':
            fm = AuthenticationForm(request = request, data= request.POST)
            if fm.is_valid():
                uname = fm.cleaned_data['username']
                upass = fm.cleaned_data['password']
                user = authenticate(username=uname, password=upass)
                if user is not None:
                    login(request, user)
                    messages.success(request, 'Logged in Successfuly!')
                    return HttpResponseRedirect('/profile/')
        else:
          fm = AuthenticationForm()
        return render(request, 'user/login.html', {'form':fm})
    else:
        return HttpResponseRedirect('/profile/')    

##Profile

def user_profile(request):
    if request.user.is_authenticated:
        if request.method == 'POST':
            if request.user.is_superuser == True:
                fm = EditAdminProfileForm(request.POST,instance=request.user)
                users = User.objects.all()
            else:    
               fm = EditUserProfileForm(request.POST, instance=request.user)
               users = None
            if fm.is_valid():
                messages.success(request, 'Profile Updated')
                fm.save()
        else:
          if request.user.is_superuser == True:
              fm = EditAdminProfileForm(instance=request.user)
              users = User.objects.all()
          else:

           fm = EditUserProfileForm(instance=request.user)
           users = None
        return render(request, 'user/profile.html', {'name':request.user.username,'form':fm, 'users':users})
    else:
        return HttpResponseRedirect('/login/')

    
##logout

def user_logout(request):
    logout(request)
    return HttpResponseRedirect('/login/')

###change password
def user_changepass(request):
    if request.user.is_authenticated:
        if request.method == 'POST':
          fm = PasswordChangeForm(user=request.user, data=request.POST)
          if fm.is_valid():
            fm.save()
            update_session_auth_hash(request, fm.user)
            messages.success(request, 'Password Changed Succesfully')
            return HttpResponseRedirect('/profile/')
        else:        
          fm = PasswordChangeForm(user=request.user)
        return render(request, 'user/changepass.html',{'form':fm})
    else:
        return HttpResponseRedirect('/login/')        
   
#user detail
def user_detail(request,id):
    if request.user.is_authenticated:
        pi = User.objects.get(pk=id)
        fm = EditAdminProfileForm(instance=pi)
        return render(request, 'user/userdetail.html',{'form':fm})
    else:
        return HttpResponseRedirect('/login/')     

#dashboard
#def user_dashboard(request):
    #if request.user.is_authenticated:
        #return render(request, 'user/dashboard.html', {'name':request.user.username})
    #else:
        #return HttpResponseRedirect('/login/')            


#api
class ApiRoot(generics.GenericAPIView):
    name = 'api-root'
    def get(self, request, *args, **kwargs):
        return Response({
            'robot-categories': reverse(RobotCategoryList.name, request=request),
            'manufacturers': reverse(ManufacturerList.name, request=request),
            'robots': reverse(RobotList.name, request=request)
            })    
  
  
class RobotCategoryList(generics.ListCreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    name = 'robotcategory-list'
  
class RobotCategoryDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    name = 'robotcategory-detail'
  
class ManufacturerList(generics.ListCreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer
    name= 'manufacturer-list'
  

class RobotList(generics.ListCreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    name = 'robot-list'
  
class RobotDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer
    name = 'robot-detail'

###DASHboard
def dashboard_list(request):
    context = {'user': User.objects.all()}
    return render(request, "user/dashboardlist.html", context)


def user_dashboard(request,id=0):
    if request.method == "GET":
        if id == 0:
            form = UserChangeForm()
        else:
            emp = User.objects.get(pk=id)
            form = UserChangeForm(instance=emp)
        return render(request, "user/dashboard.html", {'form': form})
    else:
        if id == 0:
            form = UserChangeForm(request.POST)
        else:
            emp = User.objects.get(pk=id)
            form = UserChangeForm(request.POST,instance= emp)
        if form.is_valid():
            form.save()
            
            return HttpResponseRedirect('/dashboard/list')


def dashboard_delete(request,id):
    user = User.objects.get(pk=id)
    user.delete()
    return HttpResponseRedirect('/userdashboard')
