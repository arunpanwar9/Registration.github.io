from django.urls import path
from . import views


urlpatterns = [
    path('signup/', views.signup,name='signup'),
    path('login/', views.user_login, name='login'),
    path('profile/', views.user_profile, name='profile'),
    path('logout/', views.user_logout, name='logout'),
    path('changepass/', views.user_changepass, name='changepass'),
    path('userdetail/<int:id>', views.user_detail, name='userdetail'),
     path('userdashboard', views.user_dashboard, name='userdashboard'),

     #api

    path('robocategory/',
         views.RobotCategoryList.as_view(),
         name='robotcategory-list'),
    path('robocategory/<int:pk>/',
         views.RobotCategoryDetail.as_view(),
         name='robotcategory-detail'),
    path('manufacturer/',
         views.ManufacturerList.as_view(),
         name='manufacturer-list'),
    
    path('robot/',
         views.RobotList.as_view(),
         name='robot-list'),
    path('robot/<int:pk>/',
         views.RobotDetail.as_view(),
         name='robot-detail'),
    path('api/',
        views.ApiRoot.as_view(),
        name=views.ApiRoot.name)
]     
